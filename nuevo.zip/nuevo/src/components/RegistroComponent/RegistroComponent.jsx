import React, { useState } from "react";
import "./RegistroComponent.css";

function App() {
    return (
        <div className="container">
            <div className="input-container">
                <img src="/correoicon.png" alt="" className="icon" />
                <input type="text" className="input-field" />
            </div>
            <div className="input-container">
                <img src="/password.png" alt="" className="icon" />
                <input type="text" className="input-field" />
            </div>
            <div>
                <button>Registrarse</button>
            </div>
        </div>
    );
}

export default App;
