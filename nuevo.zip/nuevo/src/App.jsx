import "./App.css";
import RegistroComponent from "./components/RegistroComponent/RegistroComponent";


function App() {
  //let nombre = "miriam";
  //let apellido = "yama";
  //let edad = "20";
  return (
  
   //<div>
   // <h1 className="decoration-double">{ nombre }</h1>
   // <h2 className="decoration-double">{ apellido }</h2>
   // <h3 className="decoration-double">{ edad }</h3>
   //</div>
   <div>
      <RegistroComponent registro="miri"></RegistroComponent>


     
   </div>


  );
}

export default App;