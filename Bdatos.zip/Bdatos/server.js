const express = require ('express');
const mysql = require('mysql');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json()); // Para poder parsear JSON

app.listen( 3000, ()=> {
    console.log("Server prendido");
});

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'M2003d12',
    database: 'biblioteca'
})

connection.connect((err)=> {
    if (err) {
        console.error("Error de conexión: ", err);
    }
    console.log("Conexion realizada!");
});

app.get('/autores', (req, res) => {
    connection.query("SELECT * FROM autores", (err, rows) => {
        if (err) {
            console.error("Error de conexión: ", err);
            res.status(500).send("Error interno del servidor");
        }

        console.log(rows);
        res.json(rows);
    });
});

app.post('/autores', (req, res) => {
    const { autor_id, nombre_autor } = req.body;
    const query = "INSERT INTO autores (autor_id, nombre_autor) VALUES (?, ?)";

    connection.query(query, [autor_id, nombre_autor], (err, result) => {
        if (err) {
            console.error("Error de conexión: ", err);
            res.status(500).send("Error interno del servidor");
        }

        console.log(result);
        res.status(201).send("autor creado exitosamente");
    });
});

app.put('/autores/:id', (req, res) => {
    const { nombre_autor } = req.body;
    const query = "UPDATE autores SET nombre_autor = ? WHERE autor_id = ?";

    connection.query(query, [nombre_autor, req.params.id], (err, result) => {
        if (err) {
            console.error("Error de conexión: ", err);
            res.status(500).send("Error interno del servidor");
        }
        //estatus 200 es que todo esta en orden

        console.log(result);
        res.status(200).send("autor actualizado correctamente");
    });
});

app.delete('/autores/:id', (req, res) => {
    const query = "DELETE FROM autores WHERE autor_id = ?";

    connection.query(query, [req.params.id], (err, result) => {
        if (err) {
            console.error("Error de conexión: ", err);
            res.status(500).send("Error interno del servidor");
        }

        console.log(result);
        res.status(200).send("autor eliminado exitosamente");
    });
}); 

//mysqltutorial.org
//"UPDATE autores SET nombre_autor = ? WHERE autor_id = ?"; para hacer una actualizacion
//repasar la sintaxis del CRUD
//css layout Generator y quickreference para buscar metodos y variables
//tailwindcss